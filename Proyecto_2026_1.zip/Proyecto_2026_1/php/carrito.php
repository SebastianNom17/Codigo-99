<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// Validar que el usuario haya iniciado sesión correctamente
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$method = $_SERVER['REQUEST_METHOD'];

// GET: Obtener todos los productos almacenados en el carrito del usuario
if ($method === 'GET') {
    // Retornar los registros del carrito
    $stmt = $pdo->prepare("SELECT id as carrito_id, producto_id, cantidad, talla, color FROM carrito WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    $items = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'items' => $items]);
} 
// POST: Agregar un nuevo producto al carrito o incrementar su cantidad
elseif ($method === 'POST') {
    $producto_id = $_POST['producto_id'] ?? 0;
    $cantidad = $_POST['cantidad'] ?? 1;
    $talla = $_POST['talla'] ?? 'N/A';
    $color = $_POST['color'] ?? 'N/A';
    
    if (!$producto_id) {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        exit;
    }
    
    // Verificar si el artículo (mismo ID, talla y color) ya existe en el carrito del usuario
    $stmt = $pdo->prepare("SELECT id, cantidad FROM carrito WHERE usuario_id = ? AND producto_id = ? AND talla = ? AND color = ?");
    $stmt->execute([$usuario_id, $producto_id, $talla, $color]);
    $existente = $stmt->fetch();
    
    if ($existente) {
        // Incrementar la cantidad si ya se encuentra en el carrito
        $nueva_cantidad = $existente['cantidad'] + $cantidad;
        $stmtUpdate = $pdo->prepare("UPDATE carrito SET cantidad = ? WHERE id = ?");
        $stmtUpdate->execute([$nueva_cantidad, $existente['id']]);
    } else {
        // Insertar un nuevo registro de artículo en el carrito si es la primera vez que se agrega
        $stmtInsert = $pdo->prepare("INSERT INTO carrito (usuario_id, producto_id, cantidad, talla, color) VALUES (?, ?, ?, ?, ?)");
        $stmtInsert->execute([$usuario_id, $producto_id, $cantidad, $talla, $color]);
    }
    
    echo json_encode(['success' => true, 'message' => 'Producto agregado al carrito']);
} 
// DELETE: Remover un producto del carrito
elseif ($method === 'DELETE') {
    parse_str(file_get_contents("php://input"), $delete_vars);
    $carrito_id = $delete_vars['carrito_id'] ?? 0;
    
    if ($carrito_id) {
        // Eliminar el registro del carrito validando la pertenencia al usuario actual
        $stmt = $pdo->prepare("DELETE FROM carrito WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$carrito_id, $usuario_id]);
        echo json_encode(['success' => true, 'message' => 'Producto eliminado']);
    } else {
        echo json_encode(['success' => false, 'message' => 'ID no proporcionado']);
    }
}
?>