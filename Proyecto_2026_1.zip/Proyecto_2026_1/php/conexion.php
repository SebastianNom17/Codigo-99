<?php
// Iniciar la sesión global para todo el aplicativo
session_start();

// Configuración de credenciales de la base de datos
$host = 'localhost';
$db   = 'codigo99';
$user = 'root';
$pass = '';

// Configuración de PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lanzar excepciones en caso de errores de SQL
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,                  
];

try {
    // Establecer conexión con la base de datos mediante la biblioteca PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, $options);
} catch (\PDOException $e) {
    // Retornar error y finalizar ejecución si falla la conexión
    die(json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']));
}
?>