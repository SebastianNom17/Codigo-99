<?php
require_once 'conexion.php';

header('Content-Type: application/json');

// Verificar sesión activa
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado. Por favor inicie sesión.']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// POST: Actualizar datos de la cuenta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Si se envía un campo 'accion' y es 'eliminar', procesar como eliminación
    if (isset($_POST['accion']) && $_POST['accion'] === 'eliminar') {
        eliminarCuenta($pdo, $usuario_id);
        exit;
    }

    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $correo = trim($_POST['correo'] ?? '');

    if (empty($nombre) || empty($apellido) || empty($correo)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
        exit;
    }

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'El correo electrónico no es válido.']);
        exit;
    }

    try {
        // Verificar si el correo ya está en uso por otro usuario
        $stmtCheck = $pdo->prepare("SELECT id FROM usuarios WHERE correo = ? AND id != ?");
        $stmtCheck->execute([$correo, $usuario_id]);
        if ($stmtCheck->fetch()) {
            echo json_encode(['success' => false, 'message' => 'El correo electrónico ya está registrado por otro usuario.']);
            exit;
        }

        // Actualizar datos del usuario
        $stmtUpdate = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ? WHERE id = ?");
        $stmtUpdate->execute([$nombre, $apellido, $correo, $usuario_id]);

        // Sincronizar variables de sesión
        $_SESSION['usuario_nombre'] = $nombre;
        $_SESSION['usuario_apellido'] = $apellido;
        $_SESSION['usuario_correo'] = $correo;

        echo json_encode([
            'success' => true, 
            'message' => 'Información de cuenta actualizada correctamente.',
            'usuario' => [
                'nombre' => $nombre,
                'apellido' => $apellido,
                'correo' => $correo
            ]
        ]);
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar los datos en la base de datos: ' . $e->getMessage()]);
    }
    exit;
}

// Método DELETE o POST alternativo: Eliminar cuenta permanentemente
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    eliminarCuenta($pdo, $usuario_id);
    exit;
}

function eliminarCuenta($pdo, $usuario_id) {
    try {
        // Eliminar usuario
        $stmtDelete = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmtDelete->execute([$usuario_id]);

        // Destruir la sesión completamente
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        echo json_encode(['success' => true, 'message' => 'Tu cuenta ha sido eliminada permanentemente.']);
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error al eliminar la cuenta de la base de datos: ' . $e->getMessage()]);
    }
}
?>