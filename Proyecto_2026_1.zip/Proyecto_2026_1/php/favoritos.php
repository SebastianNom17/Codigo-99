<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// Validar que el usuario haya iniciado sesión correctamente
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$method = $_SERVER['REQUEST_METHOD'];

// GET: Obtener la lista de IDs de productos marcados como favoritos por el usuario
if ($method === 'GET') {
    $stmt = $pdo->prepare("SELECT producto_id FROM favoritos WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    echo json_encode(['success' => true, 'favoritos' => $stmt->fetchAll()]);
} 
// POST: Alternar el estado de favorito (añadir si no existe, remover si ya existe)
elseif ($method === 'POST') {
    $producto_id = $_POST['producto_id'] ?? 0;
    
    if (!$producto_id) {
        echo json_encode(['success' => false, 'message' => 'ID no proporcionado']);
        exit;
    }
    
    // Verificar si el producto ya está en la lista de favoritos del usuario
    $stmt = $pdo->prepare("SELECT id FROM favoritos WHERE usuario_id = ? AND producto_id = ?");
    $stmt->execute([$usuario_id, $producto_id]);
    $fav = $stmt->fetch();
    
    if ($fav) {
        // Remover de favoritos si ya existía
        $stmtDel = $pdo->prepare("DELETE FROM favoritos WHERE id = ?");
        $stmtDel->execute([$fav['id']]);
        echo json_encode(['success' => true, 'is_favorite' => false]);
    } else {
        // Agregar a favoritos si no existía
        $stmtAdd = $pdo->prepare("INSERT INTO favoritos (usuario_id, producto_id) VALUES (?, ?)");
        $stmtAdd->execute([$usuario_id, $producto_id]);
        echo json_encode(['success' => true, 'is_favorite' => true]);
    }
}
?>