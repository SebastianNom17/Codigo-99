<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// GET: Validar si existe una sesión activa del usuario
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_SESSION['usuario_id'])) {
        echo json_encode([
            'success' => true,
            'usuario' => [
                'id' => $_SESSION['usuario_id'],
                'nombre' => $_SESSION['usuario_nombre'],
                'apellido' => $_SESSION['usuario_apellido'] ?? '',
                'correo' => $_SESSION['usuario_correo'] ?? '',
                'inicial' => substr($_SESSION['usuario_nombre'], 0, 1)
            ]
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// POST: Procesar el inicio de sesión del usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    // Validar campos obligatorios
    if (empty($correo) || empty($contrasena)) {
        echo json_encode(['success' => false, 'message' => 'Faltan datos']);
        exit;
    }

    // Consultar el usuario en la base de datos por su correo electrónico
    $stmt = $pdo->prepare("SELECT id, nombre, apellido, correo, contrasena FROM usuarios WHERE correo = ?");
    $stmt->execute([$correo]);
    $usuario = $stmt->fetch();

    // Validar contraseña utilizando hash seguro
    if ($usuario && password_verify($contrasena, $usuario['contrasena'])) {
        // Almacenar datos del usuario en la sesión global
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nombre'] = $usuario['nombre'];
        $_SESSION['usuario_apellido'] = $usuario['apellido'];
        $_SESSION['usuario_correo'] = $usuario['correo'];
        echo json_encode(['success' => true, 'message' => 'Login exitoso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Credenciales incorrectas']);
    }
}
?>