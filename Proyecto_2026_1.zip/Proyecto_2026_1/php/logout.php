<?php
// Iniciar el contexto de sesión existente
session_start();

// Liberar todas las variables registradas en la sesión activa
session_unset();

// Destruir por completo la información asociada a la sesión del servidor
session_destroy();

// Devolver una respuesta confirmando el cierre exitoso
header('Content-Type: application/json');
echo json_encode(['success' => true]);
?>