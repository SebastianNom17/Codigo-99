<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// Validar que el usuario haya iniciado sesión correctamente
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// POST: Procesar la pasarela de pago y registrar la transacción
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $direccion = $_POST['direccion'] ?? '';
    $metodo_pago = $_POST['metodo_pago'] ?? '';
    $total = $_POST['total'] ?? 0;
    $items_json = $_POST['items_json'] ?? '[]'; // Recibe el listado detallado de artículos
    
    // Validar campos requeridos para el envío y facturación
    if (empty($direccion) || empty($metodo_pago) || empty($total)) {
        echo json_encode(['success' => false, 'message' => 'Faltan datos de envío, pago o carrito']);
        exit;
    }
    
    $items = json_decode($items_json, true);
    if (!is_array($items) || count($items) === 0) {
        echo json_encode(['success' => false, 'message' => 'El carrito está vacío o datos inválidos']);
        exit;
    }
    
    try {
        // Iniciar una transacción
        $pdo->beginTransaction();
        
        // 1. Registrar la cabecera principal del pedido
        $stmtPedido = $pdo->prepare("INSERT INTO pedidos (usuario_id, total, metodo_pago, direccion_envio) VALUES (?, ?, ?, ?)");
        $stmtPedido->execute([$usuario_id, $total, $metodo_pago, $direccion]);
        $pedido_id = $pdo->lastInsertId();
        
        // 2. Insertar cada uno de los productos comprados en la tabla de detalles
        $stmtDetalle = $pdo->prepare("INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, precio_unitario, talla, color) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($items as $item) {
            $stmtDetalle->execute([$pedido_id, $item['producto_id'], $item['cantidad'], $item['precio'], $item['talla'], $item['color']]);
        }
        
        // 3. Limpiar el carrito del usuario tras completarse la compra de forma exitosa
        $stmtVaciar = $pdo->prepare("DELETE FROM carrito WHERE usuario_id = ?");
        $stmtVaciar->execute([$usuario_id]);
        
        // Confirmar la transacción de forma definitiva
        $pdo->commit();
        
        echo json_encode(['success' => true, 'message' => 'Compra finalizada con éxito', 'pedido_id' => $pedido_id]);
    } catch (\Exception $e) {
        // En caso de cualquier falla, revertir todos los cambios realizados
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Error al procesar el pago: ' . $e->getMessage()]);
    }
}
?>