<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// Validar que el usuario haya iniciado sesión correctamente
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autenticado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// GET: Recuperar el historial de pedidos del usuario autenticado
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Obtener la cabecera de todos los pedidos del usuario ordenados por fecha descendente
    $stmt = $pdo->prepare("SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY fecha_pedido DESC");
    $stmt->execute([$usuario_id]);
    $pedidos = $stmt->fetchAll();
    
    // Obtener los detalles de productos para cada uno de los pedidos
    foreach ($pedidos as &$pedido) {
        $stmtDet = $pdo->prepare("SELECT producto_id, cantidad, precio_unitario, talla, color FROM detalles_pedido WHERE pedido_id = ?");
        $stmtDet->execute([$pedido['id']]);
        $pedido['detalles'] = $stmtDet->fetchAll();
    }
    
    echo json_encode(['success' => true, 'pedidos' => $pedidos]);
}
?>