<?php
// Conexión a la BD e inicio de sesión
require_once 'conexion.php';
header('Content-Type: application/json');

// POST: Registrar una nueva cuenta de usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    // Validar campos obligatorios
    if (empty($nombre) || empty($apellido) || empty($correo) || empty($contrasena)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    // Consultar si el correo electrónico ya se encuentra registrado
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE correo = ?");
    $stmt->execute([$correo]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'El correo ya está registrado']);
        exit;
    }

    // Generar hash seguro para la contraseña
    $hash = password_hash($contrasena, PASSWORD_DEFAULT);

    try {
        // Insertar el nuevo registro de usuario en la base de datos
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, correo, contrasena) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nombre, $apellido, $correo, $hash]);
        
        // Iniciar sesión automáticamente tras completar el registro de forma exitosa
        $_SESSION['usuario_id'] = $pdo->lastInsertId();
        $_SESSION['usuario_nombre'] = $nombre;
        
        echo json_encode(['success' => true, 'message' => 'Registro exitoso']);
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error al registrar']);
    }
}
?>
