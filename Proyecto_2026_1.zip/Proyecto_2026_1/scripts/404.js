// Manejo e inicialización para la vista de error 404 (Página no encontrada)
document.addEventListener('DOMContentLoaded', () => {
    // Código de inicialización de la página de error
});