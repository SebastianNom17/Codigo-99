document.addEventListener('DOMContentLoaded', () => {
    // Configurar controladores interactivos para el menú lateral del carrito
    setTimeout(() => {
        const cartIcon = document.getElementById('cart-icon');
        const cartSidebar = document.getElementById('cart-sidebar');
        const cartOverlay = document.getElementById('cart-overlay');
        const closeCartBtn = document.getElementById('close-cart');
        const btnCheckout = document.getElementById('btn-checkout');

        if (cartIcon && cartSidebar) {
            cartIcon.addEventListener('click', (e) => { e.preventDefault(); openCart(); });
            closeCartBtn.addEventListener('click', closeCart);
            cartOverlay.addEventListener('click', closeCart);

            btnCheckout.addEventListener('click', () => {
                if (!window.userIsLoggedIn) {
                    window.location.href = 'login.html';
                } else {
                    window.location.href = 'pago.html';
                }
            });
        }
    }, 100);
});

// Desplegar visualmente el menú lateral del carrito
function openCart() {
    if (!window.userIsLoggedIn) {
        showToast("Debes iniciar sesión para acceder al carrito", "error");
        return;
    }
    document.getElementById('cart-sidebar').classList.add('open');
    document.getElementById('cart-overlay').classList.add('show');
    loadCart();
}

// Ocultar visualmente el menú lateral del carrito
function closeCart() {
    document.getElementById('cart-sidebar').classList.remove('open');
    document.getElementById('cart-overlay').classList.remove('show');
}

// Cargar los productos del carrito
async function loadCart() {
    if (!window.userIsLoggedIn) {
        updateCartBadge(0);
        return;
    }

    try {
        const res = await fetch('php/carrito.php');
        const data = await res.json();

        const container = document.getElementById('cart-items-container');
        const totalPriceEl = document.getElementById('cart-total-price');
        const btnCheckout = document.getElementById('btn-checkout');

        if (data.success) {
            let totalQuantity = 0;
            if (data.items.length === 0) {
                container.innerHTML = '<p class="text-center mt-4 text-muted">Tu carrito está vacío.</p>';
                totalPriceEl.textContent = formatPrice(0);
                btnCheckout.disabled = true;
                updateCartBadge(0);
            } else {
                let html = '';
                let total = 0;
                data.items.forEach(item => {
                    totalQuantity += parseInt(item.cantidad);
                    const prodInfo = getProductById(item.producto_id);
                    if (prodInfo) {
                        const subtotal = prodInfo.precio * item.cantidad;
                        total += subtotal;

                        html += `
                            <div class="cart-item fade-in">
                                <img src="${prodInfo.imagen}" alt="${prodInfo.nombre}" class="cart-item-img">
                                <div class="cart-item-details">
                                    <div class="cart-item-title">${prodInfo.nombre}</div>
                                    <div class="cart-item-variants text-muted">
                                        ${item.talla !== 'N/A' ? `Talla: ${item.talla}` : ''} 
                                        ${item.color !== 'N/A' ? `| Color: ${item.color}` : ''} 
                                        | Cant: ${item.cantidad}
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <div class="cart-item-price">${formatPrice(subtotal)}</div>
                                        <button class="cart-item-remove" onclick="removeFromCart(${item.carrito_id})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                    }
                });
                container.innerHTML = html;
                totalPriceEl.textContent = formatPrice(total);
                btnCheckout.disabled = false;
                updateCartBadge(totalQuantity);
            }
        }
    } catch (e) {
        console.error('Error al cargar el carrito:', e);
    }
}

// Agregar un producto al carrito mediante la tienda
async function addToCart(event, formElement, producto_id) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }

    if (!window.userIsLoggedIn) {
        showToast("Debes iniciar sesión para agregar productos al carrito", "error");
        return false;
    }

    const formData = new FormData(formElement);
    formData.append('cantidad', 1);

    try {
        const res = await fetch('php/carrito.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) {
            showToast("Producto agregado al carrito", "success");
            loadCart(); // Actualizar el listado en segundo plano
        } else {
            showToast(data.message, "error");
        }
    } catch (e) {
        console.error('Error al agregar al carrito:', e);
    }
    return false;
}

// Eliminar permanentemente un producto del carrito
async function removeFromCart(carrito_id) {
    try {
        const res = await fetch('php/carrito.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'carrito_id=' + carrito_id
        });
        const data = await res.json();
        if (data.success) {
            loadCart();
        }
    } catch (e) {
        console.error('Error al eliminar del carrito:', e);
    }
}

// Agregar o quitar un producto de la lista de favoritos
async function toggleFavorite(producto_id, btnElement) {
    if (!window.userIsLoggedIn) {
        showToast("Debes iniciar sesión para agregar productos a favoritos", "error");
        return;
    }

    const formData = new FormData();
    formData.append('producto_id', producto_id);

    try {
        const res = await fetch('php/favoritos.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) {
            if (data.is_favorite) {
                if (btnElement) btnElement.classList.add('active');
                if (typeof userWishlist !== 'undefined') userWishlist.push(parseInt(producto_id));
                showToast("Agregado a favoritos", "success");
            } else {
                if (btnElement) btnElement.classList.remove('active');
                if (typeof userWishlist !== 'undefined') {
                    userWishlist = userWishlist.filter(id => id !== parseInt(producto_id));
                }
                showToast("Eliminado de favoritos", "success");
            }
        }
    } catch (e) {
        console.error('Error al alternar favorito:', e);
    }
}

// Actualizar el contador numérico del ícono del carrito en el navbar
function updateCartBadge(count) {
    const badge = document.getElementById('cart-badge');
    if (badge) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }
}