document.addEventListener('DOMContentLoaded', () => {
    // Verifica si el usuario ya inició sesión
    if (window.userIsLoggedIn !== undefined) {
        if (!window.userIsLoggedIn) {
            window.location.href = 'login.html';
        } else {
            loadUserData();
        }
    }

    // Espera la validación de sesión en caso de que tarde en responder
    document.addEventListener('authReady', () => {
        if (!window.userIsLoggedIn) {
            window.location.href = 'login.html';
        } else {
            loadUserData();
        }
    });

    // Formulario para actualizar los datos de la cuenta
    const formConfig = document.getElementById('form-config-cuenta');
    if (formConfig) {
        formConfig.addEventListener('submit', guardarCambios);
    }

    // Botón encargado de abrir la ventana de confirmación
    const btnDelete = document.getElementById('btn-delete-cuenta');
    if (btnDelete) {
        btnDelete.addEventListener('click', () => {
            const modalEl = document.getElementById('confirmDeleteModal');
            if (modalEl) {
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
            }
        });
    }

    // Acción final para eliminar la cuenta
    const btnConfirmDelete = document.getElementById('btn-confirm-delete-action');
    if (btnConfirmDelete) {
        btnConfirmDelete.addEventListener('click', eliminarCuentaAction);
    }
});

// Cargar los datos actuales del usuario en el formulario
async function loadUserData() {
    try {
        const res = await fetch('php/login.php');
        const data = await res.json();
        if (data.success && data.usuario) {
            const nombreInput = document.getElementById('nombre');
            const apellidoInput = document.getElementById('apellido');
            const correoInput = document.getElementById('correo');

            if (nombreInput) nombreInput.value = data.usuario.nombre || '';
            if (apellidoInput) apellidoInput.value = data.usuario.apellido || '';
            if (correoInput) correoInput.value = data.usuario.correo || '';
        }
    } catch (e) {
        console.error('Error al cargar datos del usuario:', e);
    }
}

// Guarda los cambios realizados en la configuración de la cuenta
async function guardarCambios(e) {
    e.preventDefault();

    const form = e.target;
    if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    const btn = document.getElementById('btn-save-cuenta');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...';

    const formData = new FormData(form);

    try {
        const res = await fetch('php/cuenta.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();

        if (data.success) {
            showToast(data.message, 'success');

            // Actualiza los datos guardados localmente
            if (data.usuario) {
                const fullName = `${data.usuario.nombre} ${data.usuario.apellido}`.trim();
                sessionStorage.setItem('clientFullName', fullName);
                sessionStorage.setItem('clientEmail', data.usuario.correo);
            }

            // Recarga la página para reflejar los nuevos datos
            setTimeout(() => {
                window.location.reload();
            }, 1200);
        } else {
            showToast(data.message, 'error');
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    } catch (err) {
        console.error(err);
        showToast('Error de red al guardar los cambios.', 'error');
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

// Eliminar la cuenta del usuario permanentemente
async function eliminarCuentaAction() {
    const btn = document.getElementById('btn-confirm-delete-action');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Eliminando...';

    try {
        const res = await fetch('php/cuenta.php', {
            method: 'DELETE'
        });
        const data = await res.json();

        if (data.success) {
            // Cerrar el modal
            const modalEl = document.getElementById('confirmDeleteModal');
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }

            showToast(data.message, 'success');

            // Limpiar datos locales de sesión
            sessionStorage.clear();
            window.userIsLoggedIn = false;

            // Redirigir al index
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        } else {
            showToast(data.message, 'error');
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    } catch (err) {
        console.error(err);
        showToast('Error al enviar la solicitud de eliminación.', 'error');
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}