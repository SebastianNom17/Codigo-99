document.addEventListener('DOMContentLoaded', loadFavorites);

// Recuperar la lista de productos favoritos del usuario desde el servidor
async function loadFavorites() {
    try {
        const res = await fetch('php/favoritos.php');
        const data = await res.json();

        const grid = document.getElementById('favorites-grid');
        if (data.success) {
            // Mostrar mensaje si la lista de favoritos está vacía
            if (data.favoritos.length === 0) {
                grid.innerHTML = '<div class="col-12 text-center py-5"><h5 class="text-muted">No tienes productos en favoritos.</h5></div>';
                return;
            }

            let html = '';
            data.favoritos.forEach(f => {
                const p = getProductById(f.producto_id);
                if (p) {
                    html += `
                        <div class="product-card card">
                            <div class="product-img-wrapper">
                                <img src="${p.imagen}" alt="${p.nombre}">
                                <button class="wishlist-btn active" onclick="removeFav(${p.id})" title="Quitar de Favoritos">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">${p.nombre}</h5>
                                <h6 class="text-accent fw-bold mb-3">${formatPrice(p.precio)}</h6>
                                <a href="tienda.html" class="btn btn-outline-custom w-100 btn-sm">Ver en tienda</a>
                            </div>
                        </div>
                    `;
                }
            });
            grid.innerHTML = html;
        } else {
            // Redirigir al inicio de sesión si no se ha autenticado
            window.location.href = 'login.html';
        }
    } catch (e) {
        console.error('Error al cargar la lista de favoritos:', e);
    }
}

// Remover un producto de favoritos e inmediatamente recargar el listado visual
async function removeFav(id) {
    await toggleFavorite(id, null);
    loadFavorites();
}