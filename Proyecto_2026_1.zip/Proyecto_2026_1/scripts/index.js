document.addEventListener('DOMContentLoaded', () => {
    // Cargar los productos recomendados o destacados en la página de inicio
    loadFeaturedProducts();
});

// Obtener los productos del catálogo y las novedades destacadas
async function loadFeaturedProducts() {
    const container = document.getElementById('featured-products');
    if (!container) return;

    try {
        const res = await fetch('php/productos.php');
        const data = await res.json();

        if (data.success && data.productos.length > 0) {
            // Seleccionar los primeros 4 productos del catálogo como destacados
            const featured = data.productos.slice(0, 4);
            let html = '';

            featured.forEach(p => {
                html += `
                    <div class="col-md-3 mb-4 fade-in">
                        <div class="product-card card">
                            <div class="product-img-wrapper">
                                <img src="${p.imagen}" alt="${p.nombre}">
                            </div>
                            <div class="card-body text-center">
                                <h6 class="card-title">${p.nombre}</h6>
                                <p class="text-accent fw-bold">${formatPrice(p.precio)}</p>
                                <a href="tienda.html" class="btn btn-outline-custom btn-sm">Ver en tienda</a>
                            </div>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }
    } catch (e) {
        console.error('Error al cargar productos destacados:', e);
    }
}