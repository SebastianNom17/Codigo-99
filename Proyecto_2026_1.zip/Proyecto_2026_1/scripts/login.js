document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        // Envío del formulario de inicio de sesión
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const btn = loginForm.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Ingresando...';

            const formData = new FormData(loginForm);

            try {
                // Enviar credenciales al backend PHP
                const res = await fetch('php/login.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();

                if (data.success) {
                    // Redireccionar al inicio en caso de autenticación exitosa
                    window.location.href = 'index.html';
                } else {
                    // Mostrar mensaje de error en el formulario
                    document.getElementById('login-error').textContent = data.message;
                    document.getElementById('login-error').classList.remove('d-none');
                    btn.disabled = false;
                    btn.textContent = 'Iniciar Sesión';
                }
            } catch (e) {
                console.error('Error durante el inicio de sesión:', e);
                btn.disabled = false;
                btn.textContent = 'Iniciar Sesión';
            }
        });
    }

    // Funcionalidad para alternar la visibilidad de la contraseña
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function () {
            const pwd = document.getElementById('contrasena');
            const type = pwd.getAttribute('type') === 'password' ? 'text' : 'password';
            pwd.setAttribute('type', type);
            if (type === 'text') {
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            } else {
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            }
        });
    }
});