document.addEventListener('DOMContentLoaded', () => {

    // Crea el contenedor de notificaciones si todavía no existe
    if (!document.getElementById('toast-container')) {
        document.body.insertAdjacentHTML('beforeend', '<div id="toast-container"></div>');
    }

    // Barra de navegación principal del sitio
    const navbarHTML = `
        <nav class="navbar navbar-expand-lg sticky-top">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="img/Logo/Logo_2.jpg" alt="Código 99">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                        <li class="nav-item"><a class="nav-link" href="tienda.html">Tienda</a></li>
                        <li class="nav-item"><a class="nav-link" href="resenas.html">Reseñas</a></li>
                    </ul>

                    <ul class="navbar-nav nav-icons flex-row justify-content-center mt-3 mt-lg-0">
                        <li class="nav-item me-2 position-relative">
                            <a class="nav-link" href="#" id="cart-icon">
                                <i class="fas fa-shopping-cart"></i>

                                <!-- Contador de productos del carrito -->
                                <span id="cart-badge" class="badge-count" style="display: none;">0</span>
                            </a>
                        </li>

                        <li class="nav-item dropdown" id="user-menu-container">
                            <!-- El menú del usuario se genera dinámicamente -->
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    `;

    // Pie de página con enlaces y redes sociales
    const footerHTML = `
        <footer class="footer">
            <div class="container">
                <div class="row">

                    <div class="col-md-4 mb-4">
                        <h5 class="fw-bold mb-3 text-white">Código 99</h5>

                        <p style="color: #b0b0b0;">
                            Tu tienda de moda con el mejor estilo y calidad.
                        </p>

                        <div class="social-icons mt-3">
                            <a href="#" style="color: #b0b0b0;"><i class="fab fa-instagram"></i></a>
                            <a href="#" style="color: #b0b0b0;"><i class="fab fa-tiktok"></i></a>
                        </div>
                    </div>

                    <div class="col-md-4 mb-4">
                        <h5 class="fw-bold mb-3 text-white">Enlaces Rápidos</h5>

                        <ul class="footer-links" style="list-style: none; padding: 0;">
                            <li><a href="tienda.html" style="color: #b0b0b0; text-decoration: none;">Tienda</a></li>
                            <li><a href="resenas.html" style="color: #b0b0b0; text-decoration: none;">Reseñas</a></li>
                            <li><a href="#" style="color: #b0b0b0; text-decoration: none;">Atención al cliente</a></li>
                            <li><a href="#" style="color: #b0b0b0; text-decoration: none;">Contacto</a></li>
                        </ul>
                    </div>

                    <div class="col-md-4 mb-4">
                        <h5 class="fw-bold mb-3 text-white">Políticas</h5>

                        <ul class="footer-links" style="list-style: none; padding: 0;">
                            <li><a href="#" style="color: #b0b0b0; text-decoration: none;">Términos y condiciones</a></li>
                            <li><a href="#" style="color: #b0b0b0; text-decoration: none;">Política de privacidad</a></li>
                            <li><a href="#" style="color: #b0b0b0; text-decoration: none;">Envíos y devoluciones</a></li>
                        </ul>
                    </div>

                </div>

                <!-- Texto inferior del footer -->
                <div class="footer-bottom mt-4 pt-3 border-top" style="border-color: rgba(255,255,255,0.1) !important; color: #888;">
                    &copy; 2026 Código 99. Todos los derechos reservados.
                </div>
            </div>
        </footer>
    `;

    // Botón flotante para atención rápida por WhatsApp
    const waHTML = `
        <a href="https://wa.me/573024932841" target="_blank" class="wa-btn" style="position:fixed; bottom:25px; right:25px; background:#25D366; color:white; border-radius:50%; width:60px; height:60px; display:flex; align-items:center; justify-content:center; font-size:30px; box-shadow:var(--shadow-md); z-index:1000; transition: all 0.3s ease-in-out; text-decoration: none !important; border: none; outline: none;">
            <i class="fab fa-whatsapp"></i>
        </a>
    `;

    // Panel lateral utilizado para mostrar el carrito de compras
    const cartHTML = `
        <div class="cart-overlay" id="cart-overlay"></div>

        <div class="cart-sidebar" id="cart-sidebar">

            <div class="cart-header">
                <h4 class="fw-bold">
                    <i class="fas fa-shopping-bag me-2"></i> Tu Carrito
                </h4>

                <button class="close-cart" id="close-cart">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="cart-body" id="cart-items-container">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary"></div>
                </div>
            </div>

            <div class="cart-footer">
                <div class="cart-total">
                    <span>Total:</span>
                    <span id="cart-total-price" class="text-accent">$0</span>
                </div>

                <button class="btn btn-primary-custom w-100 py-3 mt-2" id="btn-checkout">
                    Proceder al Pago
                </button>
            </div>

        </div>
    `;

    // Agrega todos los componentes principales al documento
    document.body.insertAdjacentHTML('afterbegin', navbarHTML);
    document.body.insertAdjacentHTML('beforeend', footerHTML);
    document.body.insertAdjacentHTML('beforeend', waHTML);
    document.body.insertAdjacentHTML('beforeend', cartHTML);

    // Verifica si el usuario tiene sesión iniciada
    checkAuthState();

    // Animación al pasar el mouse sobre el botón de WhatsApp
    const waBtn = document.querySelector('.wa-btn');

    if (waBtn) {
        waBtn.addEventListener('mouseenter', () => {
            waBtn.style.transform = 'translateY(-5px) scale(1.05)';
            waBtn.style.boxShadow = 'var(--shadow-hover)';
        });

        waBtn.addEventListener('mouseleave', () => {
            waBtn.style.transform = 'translateY(0) scale(1)';
            waBtn.style.boxShadow = 'var(--shadow-md)';
        });
    }
});

// Comprueba el estado actual de autenticación del usuario
async function checkAuthState() {

    try {
        const res = await fetch('php/login.php');
        const data = await res.json();

        const container = document.getElementById('user-menu-container');

        if (data.success && data.usuario) {

            window.userIsLoggedIn = true;

            // Guarda información del cliente para usarla en otras secciones
            const fullName = `${data.usuario.nombre} ${data.usuario.apellido || ''}`.trim();

            sessionStorage.setItem('clientFullName', fullName);
            sessionStorage.setItem('clientEmail', data.usuario.correo || '');

            // Menú desplegable para usuarios autenticados
            container.innerHTML = `
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="width: auto; padding: 5px 15px; border-radius: 20px; background: var(--secondary-color);">
                    <i class="fas fa-user-circle me-1"></i> ${data.usuario.nombre.split(' ')[0]}
                </a>

                <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="userDropdown">
                    <li><h6 class="dropdown-header text-muted">Mi Cuenta</h6></li>

                    <li><a class="dropdown-item" href="favoritos.html"><i class="fas fa-heart"></i> Mis Favoritos</a></li>

                    <li><a class="dropdown-item" href="pedidos.html"><i class="fas fa-receipt"></i> Mis Pedidos</a></li>

                    <li><a class="dropdown-item" href="cuenta.html"><i class="fas fa-cog"></i> Configurar Cuenta</a></li>

                    <li><hr class="dropdown-divider"></li>

                    <li>
                        <a class="dropdown-item text-danger" href="#" id="btn-logout">
                            <i class="fas fa-sign-out-alt text-danger"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            `;

            // Cierra la sesión y limpia datos almacenados
            document.getElementById('btn-logout').addEventListener('click', async (e) => {

                e.preventDefault();

                sessionStorage.removeItem('clientFullName');
                sessionStorage.removeItem('clientEmail');

                await fetch('php/logout.php');

                window.location.reload();
            });

            // Carga el carrito si la función existe
            if (typeof loadCart === 'function') {
                loadCart();
            }

        } else {

            // Vista por defecto para usuarios no autenticados
            window.userIsLoggedIn = false;

            sessionStorage.removeItem('clientFullName');

            container.innerHTML = `
                <a class="nav-link" href="login.html" title="Iniciar Sesión">
                    <i class="fas fa-user"></i>
                </a>
            `;
        }

        // Evento global utilizado por otros scripts para saber si la sesión ya fue validada
        document.dispatchEvent(new CustomEvent('authReady'));

    } catch (e) {

        console.error('Error al verificar el estado de autenticación:', e);

        // Muestra el icono básico de usuario si ocurre un error
        document.getElementById('user-menu-container').innerHTML = `
            <a class="nav-link" href="login.html">
                <i class="fas fa-user"></i>
            </a>
        `;
    }
}

// Sistema de notificaciones
function showToast(message, type = 'success') {

    const container = document.getElementById('toast-container');

    if (!container) return;

    // Cambia el icono dependiendo del tipo de mensaje
    const icon = type === 'success'
        ? 'fa-check-circle'
        : 'fa-exclamation-circle';

    const toast = document.createElement('div');

    toast.className = `custom-toast ${type}`;

    toast.innerHTML = `
        <i class="fas ${icon}"></i>
        <div>${message}</div>
    `;

    container.appendChild(toast);

    // Activa la animación de entrada
    setTimeout(() => toast.classList.add('show'), 10);

    // Elimina automáticamente la notificación después de unos segundos
    setTimeout(() => {
        toast.classList.remove('show');

        setTimeout(() => toast.remove(), 500);

    }, 3000);
}

// Convierte valores numéricos al formato de moneda colombiana
function formatPrice(price) {

    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0
    }).format(price);
}