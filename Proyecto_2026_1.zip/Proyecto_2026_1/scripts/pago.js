document.addEventListener('DOMContentLoaded', () => {

    // Carga el resumen del carrito apenas inicia la página
    loadCheckoutCart();

    const pagoForm = document.getElementById('pago-form');

    if (pagoForm) {

        // Maneja el envío del formulario de pago
        pagoForm.addEventListener('submit', async (e) => {

            e.preventDefault();

            const btn = pagoForm.querySelector('button[type="submit"]');

            // Desactiva el botón mientras se procesa la compra
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Procesando...';

            const formData = new FormData(pagoForm);

            // Verifica si el cliente pidió recibo PDF
            const requiereRecibo = formData.get('recibo') === 'si';

            // Envía información adicional necesaria para registrar el pedido
            formData.append('total', cartTotalAmt);
            formData.append('items_json', JSON.stringify(cartItemsForBackend));

            try {

                // Petición al servidor para guardar el pago y la orden
                const res = await fetch('php/pago.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await res.json();

                if (data.success) {

                    // Genera el recibo si el usuario activó esa opción
                    if (requiereRecibo) {
                        generarPDF(formData, data.pedido_id);
                    }

                    // Muestra mensaje de éxito
                    document.getElementById('pago-success').classList.remove('d-none');

                    // Limpia los datos del formulario
                    pagoForm.reset();

                    document.getElementById('checkout-items').innerHTML = '';
                    document.getElementById('checkout-total').textContent = '$0';

                    // Redirecciona al historial de pedidos
                    setTimeout(() => {
                        window.location.href = 'pedidos.html';
                    }, 3000);

                } else {

                    showToast(data.message, "error");

                    btn.disabled = false;
                    btn.textContent = 'Finalizar Compra';
                }

            } catch (e) {

                console.error('Error al procesar el pago:', e);

                showToast("Error procesando el pago", "error");

                btn.disabled = false;
                btn.textContent = 'Finalizar Compra';
            }
        });
    }
});

let cartTotalAmt = 0;

// Productos que se enviarán al backend
let cartItemsForBackend = [];

// Productos usados para el recibo PDF
let cartItemsForPdf = [];

// Obtiene los productos del carrito y arma el resumen de compra
async function loadCheckoutCart() {

    try {

        const res = await fetch('php/carrito.php');

        const data = await res.json();

        if (data.success) {

            const container = document.getElementById('checkout-items');

            // Verifica si el carrito está vacío
            if (data.items.length === 0) {

                container.innerHTML = '<p class="text-muted text-center">No hay productos para pagar.</p>';

                document.getElementById('btn-pagar').disabled = true;

                return;
            }

            let html = '';

            data.items.forEach(item => {

                const prodInfo = getProductById(item.producto_id);

                if (prodInfo) {

                    const subtotal = prodInfo.precio * item.cantidad;

                    // Acumula el total general de la compra
                    cartTotalAmt += subtotal;

                    // Información necesaria para guardar el pedido
                    cartItemsForBackend.push({
                        producto_id: item.producto_id,
                        cantidad: item.cantidad,
                        talla: item.talla,
                        color: item.color,
                        precio: prodInfo.precio
                    });

                    // Información usada en el PDF
                    cartItemsForPdf.push({
                        nombre: prodInfo.nombre,
                        cantidad: item.cantidad,
                        precio: prodInfo.precio
                    });

                    // Línea visual de cada producto
                    html += `
                        <div class="d-flex justify-content-between mb-2">
                            <span>${item.cantidad}x ${prodInfo.nombre}</span>
                            <span>${formatPrice(subtotal)}</span>
                        </div>
                    `;
                }
            });

            container.innerHTML = html;

            // Muestra el valor total calculado
            document.getElementById('checkout-total').textContent = formatPrice(cartTotalAmt);
        }

    } catch (e) {

        console.error('Error al cargar carrito para pago:', e);
    }
}

// Genera el recibo en PDF usando jsPDF
function generarPDF(formData, pedido_id) {

    const { jsPDF } = window.jspdf;

    const doc = new jsPDF();

    // Título principal del recibo
    doc.setFont("helvetica");

    doc.setFontSize(22);

    doc.text("Código 99", 105, 20, null, null, "center");

    doc.setFontSize(16);

    doc.text("Recibo de Compra", 105, 30, null, null, "center");

    // Datos generales del pedido
    doc.setFontSize(12);

    doc.text(`Pedido ID: #${pedido_id}`, 20, 45);

    doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 20, 52);

    const clientName = sessionStorage.getItem('clientFullName') || 'Cliente';

    // Información del comprador
    doc.text(`Cliente: ${clientName || 'Cliente'}`, 20, 65);

    doc.text(`Dirección de envío: ${formData.get('direccion')}`, 20, 72);

    doc.text(`Método de pago: ${formData.get('metodo_pago')}`, 20, 79);

    doc.line(20, 85, 190, 85);

    // Encabezados de la tabla del recibo
    doc.setFontSize(10);

    doc.text("Producto", 20, 92);

    doc.text("Cant", 120, 92);

    doc.text("Subtotal", 160, 92);

    doc.line(20, 95, 190, 95);

    // Agrega cada producto al PDF
    let y = 102;

    cartItemsForPdf.forEach(item => {

        doc.text(item.nombre.substring(0, 40), 20, y);

        doc.text(item.cantidad.toString(), 120, y);

        doc.text(formatPrice(item.precio * item.cantidad), 160, y);

        y += 8;
    });

    doc.line(20, y, 190, y);

    y += 8;

    // Total final de la compra
    doc.setFontSize(14);

    doc.text("Total:", 120, y);

    doc.text(formatPrice(cartTotalAmt), 160, y);

    // Mensaje final del recibo
    doc.setFontSize(10);

    doc.text("¡Gracias por su compra!", 105, y + 20, null, null, "center");

    // Descarga automática del archivo PDF
    doc.save(`Recibo_Codigo99_${pedido_id}.pdf`);
}