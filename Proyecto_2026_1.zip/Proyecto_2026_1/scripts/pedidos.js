document.addEventListener('DOMContentLoaded', loadPedidos);

// Obtiene y muestra el historial de compras del usuario
async function loadPedidos() {

    try {

        const res = await fetch('php/pedidos.php');

        const data = await res.json();

        const container = document.getElementById('pedidos-container');

        if (data.success) {

            // Mensaje mostrado cuando no existen pedidos registrados
            if (data.pedidos.length === 0) {

                container.innerHTML = `
                    <div class="alert bg-white shadow-sm border-0 py-4 text-center text-muted">
                        Aún no has realizado ninguna compra.
                    </div>
                `;

                return;
            }

            let html = '';

            data.pedidos.forEach(p => {

                let detallesHtml = '';

                // Productos incluidos en cada pedido
                p.detalles.forEach(d => {

                    const prodInfo = getProductById(d.producto_id);

                    if (prodInfo) {

                        detallesHtml += `
                            <div class="d-flex align-items-center mb-3 p-2 bg-light rounded">

                                <!-- Imagen del producto -->
                                <img 
                                    src="${prodInfo.imagen}" 
                                    style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px; margin-right: 15px;"
                                >

                                <div>
                                    <strong class="text-primary-color">
                                        ${prodInfo.nombre}
                                    </strong><br>

                                    <!-- Datos adicionales del producto -->
                                    <small class="text-muted">
                                        Cant: ${d.cantidad}

                                        ${d.talla !== 'N/A'
                                ? '| Talla: ' + d.talla
                                : ''
                            }

                                        ${d.color !== 'N/A'
                                ? '| Color: ' + d.color
                                : ''
                            }
                                    </small>
                                </div>

                                <!-- Precio total del producto -->
                                <div class="ms-auto fw-bold text-accent">
                                    ${formatPrice(d.precio_unitario * d.cantidad)}
                                </div>

                            </div>
                        `;
                    }
                });

                // Tarjeta principal de cada pedido
                html += `
                    <div class="card mb-4 border-0 shadow-sm" style="border-radius: 12px; overflow:hidden;">

                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom-0">

                            <div>
                                <h5 class="mb-0 fw-bold">
                                    Pedido #${p.id}
                                </h5>

                                <small class="text-muted">
                                    ${new Date(p.fecha_pedido).toLocaleDateString()}
                                </small>
                            </div>

                            <div class="text-end">

                                <!-- Estado actual del pedido -->
                                <span class="badge bg-success mb-1">
                                    Completado
                                </span>

                                <!-- Total pagado -->
                                <div class="fw-bold text-accent">
                                    ${formatPrice(p.total)}
                                </div>

                            </div>

                        </div>

                        <div class="card-body bg-white">

                            ${detallesHtml}

                            <hr class="text-muted">

                            <!-- Información de envío y método de pago -->
                            <div class="row text-muted small">

                                <div class="col-md-6">
                                    <strong>
                                        <i class="fas fa-map-marker-alt"></i> Dirección:
                                    </strong>

                                    ${p.direccion_envio}
                                </div>

                                <div class="col-md-6 text-md-end">
                                    <strong>
                                        <i class="fas fa-credit-card"></i> Método:
                                    </strong>

                                    ${p.metodo_pago}
                                </div>

                            </div>

                        </div>

                    </div>
                `;
            });

            // Inserta todas las tarjetas en el contenedor
            container.innerHTML = html;

        } else {

            // Envía al usuario al login si no tiene sesión iniciada
            window.location.href = 'login.html';
        }

    } catch (e) {

        console.error('Error al cargar historial de pedidos:', e);
    }
}