﻿const catalogProductos = [
    // HOMBRE - CAMISAS / CAMISETAS (101 - 110)
    {
        id: 101,
        nombre: 'Camiseta Básica',
        descripcion: 'Camiseta de algodón 100% transpirable, perfecta para el uso diario.',
        precio: 45000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camiseta_Basica.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 102,
        nombre: 'Camisa Formal Slim',
        descripcion: 'Camisa formal de corte ajustado, ideal para oficina o eventos especiales.',
        precio: 85000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_Formal_Slim.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 103,
        nombre: 'Polo Piqué',
        descripcion: 'Camiseta polo clásica en tejido piqué, cómoda y elegante.',
        precio: 65000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Polo_Pique.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 104,
        nombre: 'Camiseta Estampada Vintage',
        descripcion: 'Camiseta casual con estampado retro de alta durabilidad.',
        precio: 48000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camiseta_Estampada_Vintage.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 105,
        nombre: 'Camisa de Lino',
        descripcion: 'Camisa ligera y fresca, perfecta para días cálidos o de playa.',
        precio: 95000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_De_Lino.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 106,
        nombre: 'Camisa Oxford',
        descripcion: 'Camisa casual en tejido Oxford resistente y de tacto suave.',
        precio: 89000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_Oxford.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 107,
        nombre: 'Camiseta Manga Larga',
        descripcion: 'Camiseta versátil de manga larga, algodón premium.',
        precio: 52000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camiseta_Manga_Larga.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 108,
        nombre: 'Camisa Cuadros Leñador',
        descripcion: 'Camisa de franela a cuadros, estilo rústico y abrigador.',
        precio: 78000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_Cuadros_Leñador.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 109,
        nombre: 'Camiseta Deportiva Dry-Fit',
        descripcion: 'Camiseta transpirable de secado rápido para entrenamiento duro.',
        precio: 40000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_Deportiva_DryFit.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 110,
        nombre: 'Camisa Guayabera',
        descripcion: 'Tradicional guayabera en lino fino con alforzas clásicas.',
        precio: 110000,
        categoria: 'Camisas / Camisetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Camisas_Camisetas/Camisa_Guayabera.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // HOMBRE - PANTALONES (111 - 120)
    {
        id: 111,
        nombre: 'Pantalón Denim Clásico',
        descripcion: 'Pantalón vaquero de corte recto. Resistencia y estilo en uno.',
        precio: 120000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Pantalon_Denim_Clasico.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 112,
        nombre: 'Pantalón Chino Slim',
        descripcion: 'Pantalón chino elástico, ideal para un look casual de negocios.',
        precio: 115000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Pantalon_Chino_Slim.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 113,
        nombre: 'Pantalón Cargo',
        descripcion: 'Pantalón cargo resistente con múltiples bolsillos funcionales.',
        precio: 130000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Pantalon_Cargo.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 114,
        nombre: 'Jogger Deportivo',
        descripcion: 'Jogger de algodón muy suave con cordón ajustable.',
        precio: 85000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Jogger_Deportivo.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 115,
        nombre: 'Jeans Regular Fit Oscuros',
        descripcion: 'Pantalón vaquero clásico de tono oscuro y corte cómodo.',
        precio: 125000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Jeans_Regular_Fit_Oscuros.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 116,
        nombre: 'Pantalón de Vestir',
        descripcion: 'Pantalón formal sastre con pliegue marcado, excelente caída.',
        precio: 140000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Pantalon_De_Vestir.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 117,
        nombre: 'Bermudas de Algodón',
        descripcion: 'Bermuda casual de gabardina ligera para el verano.',
        precio: 68000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Bermuda_De_Algodon.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 118,
        nombre: 'Pantalón Casual de Lino',
        descripcion: 'Pantalón holgado de lino para máxima comodidad y frescura.',
        precio: 110000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Pantalon_Casual_De_Lino.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 119,
        nombre: 'Jogger Slim Fit',
        descripcion: 'Jogger estilizado de corte ajustado, ideal para el día a día.',
        precio: 88000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Jogger_Slim_Fit.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 120,
        nombre: 'Jeans Rotos Modernos',
        descripcion: 'Jeans estilo urbano con roturas decorativas y corte ajustado.',
        precio: 135000,
        categoria: 'Pantalones',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Pantalones/Jeans_Rotos_Modernos.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // HOMBRE - CHAQUETAS (121 - 130)
    {
        id: 121,
        nombre: 'Chaqueta de Cuero',
        descripcion: 'Chaqueta estilo motero de cuero sintético premium de alta duración.',
        precio: 280000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Chaqueta_De_Cuero.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 122,
        nombre: 'Cortavientos Impermeable',
        descripcion: 'Chaqueta liviana impermeable para días lluviosos o viento.',
        precio: 150000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Cortavientos_Impermeable.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 123,
        nombre: 'Chaqueta Bomber',
        descripcion: 'Chaqueta estilo militar con puños elásticos y cremallera frontal.',
        precio: 165000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Chaqueta_Bomber.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 124,
        nombre: 'Saco de Lana Premium',
        descripcion: 'Saco clásico de punto grueso tejido con lana de alta calidad.',
        precio: 140000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Saco_De_Lana_Premium.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 125,
        nombre: 'Chaqueta Denim con Cordero',
        descripcion: 'Chaqueta de jean clásica forrada en suave chiporro ovejero.',
        precio: 195000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Chaqueta_Denim_Con_Cordero.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 126,
        nombre: 'Blazer Slim Fit',
        descripcion: 'Blazer casual semiformal con forro interior satinado.',
        precio: 220000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Blazer_Slim_Fit.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 127,
        nombre: 'Parka de Invierno Térmica',
        descripcion: 'Parka acolchada impermeable con capota de felpa desmontable.',
        precio: 290000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Parka_De_Invierno_Termica.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 128,
        nombre: 'Chaqueta Acolchada Ligera',
        descripcion: 'Chaqueta ultraliviana rellena de plumón sintético, plegable.',
        precio: 180000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Chaqueta_Acolchada_Ligera.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 129,
        nombre: 'Saco Deportivo con Capota',
        descripcion: 'Hoddie clásico con capota, interior afelpado muy abrigador.',
        precio: 98000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Saco_Deportivo_Con_Capota.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 130,
        nombre: 'Chaleco Acolchado',
        descripcion: 'Chaleco acolchado sin mangas, ideal para vestir en capas.',
        precio: 120000,
        categoria: 'Chaquetas',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Chaquetas/Chaleco_Acolchado.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // HOMBRE - CALZADO (131 - 140)
    {
        id: 131,
        nombre: 'Tenis Urbanos',
        descripcion: 'Tenis casuales de cuero sintético con suela plana de goma.',
        precio: 160000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Tenis_Urbanos.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 132,
        nombre: 'Botas de Cuero',
        descripcion: 'Botas de cuero genuino con cordones y suela dentada antideslizante.',
        precio: 240000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Botas_De_Cuero.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 133,
        nombre: 'Zapatos de Vestir Oxford',
        descripcion: 'Zapatos clásicos de amarrar estilo Oxford, terminación semibrillante.',
        precio: 210000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Zapatos_De_Vestir_Oxford.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 134,
        nombre: 'Mocasines de Gamuza',
        descripcion: 'Mocasines casuales y elegantes de gamuza súper suave.',
        precio: 180000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Mocasines_De_Gamuza.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 135,
        nombre: 'Tenis de Running',
        descripcion: 'Calzado deportivo con amortiguación premium para corredores.',
        precio: 195000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Tenis_De_Running.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 136,
        nombre: 'Sandalias de Cuero Playa',
        descripcion: 'Chanclas cómodas con tiras de cuero y plantilla ergonómica.',
        precio: 85000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Sandalias_De_Cuero_Playa.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 137,
        nombre: 'Botas de Trekking Resistentes',
        descripcion: 'Botas de montaña impermeables con excelente agarre.',
        precio: 260000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Botas_De_Trekking_Resistentes.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 138,
        nombre: 'Tenis Deportivos Ligeros',
        descripcion: 'Calzado ultra liviano y cómodo para caminar o ir al gimnasio.',
        precio: 150000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Tenis_Deportivos_Ligeros.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 139,
        nombre: 'Zapatos Casuales',
        descripcion: 'Zapatos casuales de cuero nobuck con costuras reforzadas.',
        precio: 175000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Zapatos_Casuales.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 140,
        nombre: 'Alpargatas de Lino',
        descripcion: 'Alpargatas clásicas con suela de yute y tela de lino fresca.',
        precio: 75000,
        categoria: 'Calzado',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Calzado/Alpargatas_De_Lino.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // HOMBRE - ACCESORIOS (141 - 150)
    {
        id: 141,
        nombre: 'Gafas de Sol Aviador',
        descripcion: 'Gafas clásicas con marco metálico y protección UV400 completa.',
        precio: 35000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Gafas_De_Sol_Aviador.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 142,
        nombre: 'Reloj Deportivo Resistente',
        descripcion: 'Reloj digital resistente al agua (50m) con cronómetro y alarma.',
        precio: 250000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Reloj_Deportivo_Resistente.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 143,
        nombre: 'Cinturón de Cuero Reversible',
        descripcion: 'Cinturón elegante reversible negro/café en cuero 100% natural.',
        precio: 55000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Cinturon_De_Cuero_Reversible.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 144,
        nombre: 'Gorra Deportiva',
        descripcion: 'Gorra clásica con visera curva y ajuste de correa metálica.',
        precio: 45000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Gorra_Deportiva.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 145,
        nombre: 'Billetera de Cuero Slim',
        descripcion: 'Billetera ultra delgada de cuero con protección RFID de tarjetas.',
        precio: 65000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Billetera_De_Cuero.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 146,
        nombre: 'Maleta de Lona Viaje',
        descripcion: 'Maleta amplia de fin de semana en lona impermeable con correas de cuero.',
        precio: 120000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Maleta_De_Lona_Viaje.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 147,
        nombre: 'Bufanda de Lana',
        descripcion: 'Bufanda clásica tejida en lana acrílica muy suave y cálida.',
        precio: 38000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Bufanda_De_Lana.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 148,
        nombre: 'Pulsera de Cuero y Acero',
        descripcion: 'Pulsera de cuero trenzado con cierre magnético de acero inoxidable.',
        precio: 28000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Pulsera_De_Cuero_Y_Acero.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 149,
        nombre: 'Sombrero de Paja Casual',
        descripcion: 'Sombrero estilo Panamá ideal para el sol y días de descanso.',
        precio: 50000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Sombrero_De_Paja_Casual.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 150,
        nombre: 'Corbata de Seda',
        descripcion: 'Corbata elegante de pura seda con patrón jacquard clásico.',
        precio: 40000,
        categoria: 'Accesorios',
        genero: 'Hombre',
        imagen: 'img/productos/hombre/Accesorios/Corbata_De_Seda.jpg',
        requiereTalla: false,
        requiereColor: true
    },

    // MUJER - CAMISAS / CAMISETAS (201 - 210)
    {
        id: 201,
        nombre: 'Blusa Elegante Seda',
        descripcion: 'Blusa de manga larga en seda fluida, ideal para oficina o reuniones.',
        precio: 85000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Blusa_Elegante_Seda.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 202,
        nombre: 'Camiseta Básica Cuello V',
        descripcion: 'Camiseta esencial en algodón suave de corte femenino y cómodo.',
        precio: 38000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Camiseta_Basica_Cuello_V_Mujer.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 203,
        nombre: 'Top de Encaje',
        descripcion: 'Top sin mangas de tirantas finas con detalle de encaje floral.',
        precio: 48000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Top_De_Encaje.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 204,
        nombre: 'Camisa de Rayas Oversized',
        descripcion: 'Camisa casual holgada de rayas, estilo contemporáneo.',
        precio: 75000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Camisa_De_Rayas_Oversized.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 205,
        nombre: 'Blusa Manga Larga Floral',
        descripcion: 'Blusa de chifón con estampado floral y manga ligeramente bombacha.',
        precio: 68000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Blusa_Manga_Larga_Floral.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 206,
        nombre: 'Camiseta Crop Top',
        descripcion: 'Crop top acanalado de algodón elástico, estilo juvenil.',
        precio: 32000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Camiseta_Crop_Top.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 207,
        nombre: 'Blusa de Lino Hombros Descubiertos',
        descripcion: 'Blusa fresca con elástico en hombros y nudo en mangas.',
        precio: 78000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Blusa_De_Lino_Hombros_Descubiertos.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 208,
        nombre: 'Camisa Satinada Elegante',
        descripcion: 'Camisa de cuello clásico en satín brillante de tacto suave.',
        precio: 90000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Camisa_Satinada_Elegante.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 209,
        nombre: 'Top Deportivo Ajustado',
        descripcion: 'Top deportivo elástico de gran soporte y tela transpirable.',
        precio: 45000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Top_Deportivo_Ajustado.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 210,
        nombre: 'Camisa Mezclilla Lavada',
        descripcion: 'Camisa clásica de jean de gramaje liviano y lavado claro.',
        precio: 82000,
        categoria: 'Camisas / Camisetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Camisas_Camisetas/Camisa_Mezclilla_Lavada.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // MUJER - PANTALONES (211 - 220)
    {
        id: 211,
        nombre: 'Jeans Mom Fit',
        descripcion: 'Jeans clásicos de tiro alto y pierna relajada con algodón 100%.',
        precio: 125000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Jeans_Mom_Fit.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 212,
        nombre: 'Pantalón Palazo',
        descripcion: 'Pantalón formal palazzo de bota ancha y tiro alto súper elegante.',
        precio: 110000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Pantalon_Palazo.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 213,
        nombre: 'Jogger de Algodón',
        descripcion: 'Pantalón deportivo jogger cómodo y abrigador de interior suave.',
        precio: 78000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Jogger_De_Algodon.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 214,
        nombre: 'Pantalón de Vestir Tiro Alto',
        descripcion: 'Pantalón sastre ajustado con cinturón de tela del mismo tono.',
        precio: 130000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Pantalon_De_Vestir_Tiro_Alto.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 215,
        nombre: 'Short Denim Deshilachado',
        descripcion: 'Short vaquero clásico de verano con terminación deshilachada.',
        precio: 65000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Short_Denim_Deshilachado.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 216,
        nombre: 'Leggings Deportivos',
        descripcion: 'Calza o legging elástico de tiro alto con costuras reforzadas.',
        precio: 60000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Leggings_Deportivos.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 217,
        nombre: 'Pantalón de Lino',
        descripcion: 'Pantalón suelto y playero de puro lino con cordón en la cintura.',
        precio: 105000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Pantalon_De_Lino.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 218,
        nombre: 'Jeans Skinny Tiro Alto',
        descripcion: 'Vaquero super stretch muy ajustado de mezclilla premium.',
        precio: 120000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Jeans_Skinny_Tiro_Alto.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 219,
        nombre: 'Pantalón Paperbag',
        descripcion: 'Pantalón casual tiro alto con fruncido y lazo en la cintura.',
        precio: 98000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Pantalon_Paperbag.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 220,
        nombre: 'Jeans Acampanados Retro',
        descripcion: 'Pantalón vaquero de bota campana, un clásico de la moda retro.',
        precio: 135000,
        categoria: 'Pantalones',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Pantalones/Jeans_Acampanados_Retro.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // MUJER - CHAQUETAS (221 - 230)
    {
        id: 221,
        nombre: 'Chaqueta de Cuero Sintético',
        descripcion: 'Chaqueta estilo motero para mujer de material suave y entallado.',
        precio: 180000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Chaqueta_De_Cuero_Sintetico.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 222,
        nombre: 'Abrigo de Lana Largo',
        descripcion: 'Elegante tapado de paño largo con solapas y botones frontales.',
        precio: 320000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Abrigo_De_Lana_Largo.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 223,
        nombre: 'Blazer Entallado',
        descripcion: 'Blazer de sastre entallado, perfecto para looks formales y casuales.',
        precio: 160000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Blazer_Entallado.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 224,
        nombre: 'Chaqueta Denim Clásica',
        descripcion: 'Chaqueta vaquera de mujer en tono azul medio con bolsillos delanteros.',
        precio: 140000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Chaqueta_Denim_Clasica.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 225,
        nombre: 'Cardigan de Punto Largo',
        descripcion: 'Saco largo de punto abierto de hilo suave sin botones.',
        precio: 95000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Cardigan_De_Punto_Largo.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 226,
        nombre: 'Cortavientos Running Impermeable',
        descripcion: 'Chaqueta ultraliviana para correr en climas húmedos o viento.',
        precio: 135000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Cortavientos_Running_Impermeable.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 227,
        nombre: 'Saco de Hilo Cuello Alto',
        descripcion: 'Suéter abrigador de cuello tortuga tejido en punto acanalado.',
        precio: 88000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Saco_De_Hilo_Cuello_Alto.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 228,
        nombre: 'Parka con Capota',
        descripcion: 'Parka forrada impermeable de longitud media con cintura ajustable.',
        precio: 220000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Parka_Con_Capota.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 229,
        nombre: 'Chaqueta Bomber Satinada',
        descripcion: 'Chaqueta bomber de satín suave con forro ligero contrastado.',
        precio: 125000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Chaqueta_Bomber_Satinada.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 230,
        nombre: 'Chaleco de Plumón Ligero',
        descripcion: 'Chaleco acolchado con relleno térmico comprimible con cremallera.',
        precio: 115000,
        categoria: 'Chaquetas',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Chaquetas/Chaleco_De_Plumon_Ligero.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // MUJER - CALZADO (231 - 240)
    {
        id: 231,
        nombre: 'Sandalias de Tacón Elegantes',
        descripcion: 'Sandalias altas de tacón grueso con correa ajustable al tobillo.',
        precio: 170000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Sandalias_De_Tacon_Elegantes.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 232,
        nombre: 'Tenis Plataforma',
        descripcion: 'Tenis urbanos de cuero sintético con plataforma de 4cm súper cómodos.',
        precio: 155000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Tenis_Plataforma.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 233,
        nombre: 'Botines de Cuero',
        descripcion: 'Botines chelsea de cuero con elástico en los costados y tacón bajo.',
        precio: 220000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Botines_De_Cuero.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 234,
        nombre: 'Baletas Planas de Cuero',
        descripcion: 'Baletas o bailarinas cómodas y elegantes de punta redondeada.',
        precio: 90000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Baletas_Planas_De_Cuero.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 235,
        nombre: 'Tenis Deportivos Ligeros Femeninos',
        descripcion: 'Zapatillas running muy livianas con capellada transpirable.',
        precio: 150000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Tenis_Deportivos_Ligeros_Femeninos.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 236,
        nombre: 'Botas Altas de Gamuza',
        descripcion: 'Botas altas hasta la rodilla en cuero de gamuza con tacón de aguja.',
        precio: 280000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Botas_Altas_De_Gamuza.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 237,
        nombre: 'Mocasines Casuales',
        descripcion: 'Mocasines casuales en gamuza liviana con fleco decorativo en punta.',
        precio: 130000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Mocasines_Casuales.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 238,
        nombre: 'Sandalias Planas de Playa',
        descripcion: 'Chanclas veraniegas con tirantes brillantes y suela de corcho flexible.',
        precio: 68000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Sandalias_Planas_De_Playa.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 239,
        nombre: 'Zapatos de Salón Clásicos',
        descripcion: 'Zapatos de tacón de punta fina en acabado charol elegante.',
        precio: 190000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Zapatos_De_Salon_Clasicos.jpg',
        requiereTalla: true,
        requiereColor: true
    },
    {
        id: 240,
        nombre: 'Alpargatas de Yute',
        descripcion: 'Zapatos de lona cosidos a mano con suela tradicional de yute.',
        precio: 78000,
        categoria: 'Calzado',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Calzado/Alpargatas_De_Yute.jpg',
        requiereTalla: true,
        requiereColor: true
    },

    // MUJER - ACCESORIOS (241 - 250)
    {
        id: 241,
        nombre: 'Bolso Casual de Cuero',
        descripcion: 'Bolso tipo tote amplio de cuero con cierre metálico de alta calidad.',
        precio: 95000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Bolso_Casual_De_Cuero.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 242,
        nombre: 'Gafas de Sol Cat-Eye',
        descripcion: 'Gafas de sol de estilo ojo de gato con lentes oscuras polarizadas.',
        precio: 45000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Gafas_De_Sol_CatEeye.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 243,
        nombre: 'Sombrero de Fieltro Elegante',
        descripcion: 'Sombrero fedora de lana de ala ancha con banda decorativa de cuero.',
        precio: 75000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Sombrero_De_Fieltro_Elegante.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 244,
        nombre: 'Cartera de Mano Fiesta',
        descripcion: 'Sobre o clutch de mano con apliques de pedrería y cadena dorada fina.',
        precio: 85000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Cartera_De_Mano_Fiesta.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 245,
        nombre: 'Bufanda Estampada Seda',
        descripcion: 'Pañuelo o bufanda cuadrada de satín de seda con hermoso estampado artístico.',
        precio: 35000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Bufanda_Estampada_Seda.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 246,
        nombre: 'Cinturón Fino Hebilla Dorada',
        descripcion: 'Cinturón delgado ajustable en cuero ideal para vestidos o jeans.',
        precio: 28000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Cinturon_Fino_Hebilla_Dorada.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 247,
        nombre: 'Collar de Perlas Delicado',
        descripcion: 'Gargantilla de perlas cultivadas con broche magnético bañado en plata.',
        precio: 58000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Collar_De_Perlas_Delicado.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 248,
        nombre: 'Reloj Analógico',
        descripcion: 'Reloj clásico de cuarzo con pulsera de malla metálica en color oro rosa.',
        precio: 220000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Reloj_Analogico.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 249,
        nombre: 'Aretes de Plata Colgantes',
        descripcion: 'Pendientes o zarcillos refinados de plata de ley en forma de gota.',
        precio: 32000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Aretes_De_Plata_Colgantes.jpg',
        requiereTalla: false,
        requiereColor: true
    },
    {
        id: 250,
        nombre: 'Mochila Casual de Lona',
        descripcion: 'Morral compacto de uso diario con compartimento acolchado para tablet.',
        precio: 88000,
        categoria: 'Accesorios',
        genero: 'Mujer',
        imagen: 'img/productos/mujer/Accesorios/Mochila_Casual_De_Lona.jpg',
        requiereTalla: false,
        requiereColor: true
    }
];

// Buscar un producto por ID
function getProductById(id) {
    return catalogProductos.find(p => p.id == id) || null;
}