document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registro-form');
    if (registerForm) {
        // Maneja el envío del formulario de registro
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const btn = registerForm.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Registrando...';

            const formData = new FormData(registerForm);

            try {
                // Enviar datos de registro del nuevo cliente al servidor PHP
                const res = await fetch('php/registro.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();

                if (data.success) {
                    // Redireccionar al inicio tras registrarse e iniciar sesión automáticamente
                    window.location.href = 'index.html';
                } else {
                    // Mostrar mensaje de error de validación en el formulario
                    document.getElementById('registro-error').textContent = data.message;
                    document.getElementById('registro-error').classList.remove('d-none');
                    btn.disabled = false;
                    btn.textContent = 'Registrarse';
                }
            } catch (e) {
                console.error('Error durante el registro de cuenta:', e);
                btn.disabled = false;
                btn.textContent = 'Registrarse';
            }
        });
    }

    // Funcionalidad interactiva para alternar la visibilidad de la contraseña
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function () {
            const pwd = document.getElementById('contrasena');
            const type = pwd.getAttribute('type') === 'password' ? 'text' : 'password';
            pwd.setAttribute('type', type);
            if (type === 'text') {
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            } else {
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            }
        });
    }
});
