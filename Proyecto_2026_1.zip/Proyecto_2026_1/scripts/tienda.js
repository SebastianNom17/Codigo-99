document.addEventListener('DOMContentLoaded', () => {
    // Espera la validación de sesión para cargar los favoritos correctamente
    document.addEventListener('authReady', () => {
        fetchWishlistAndRenderHearts();
    });

    // Ejecuta la carga de favoritos por si la sesión ya estaba iniciada
    fetchWishlistAndRenderHearts();

    // Detecta cambios en los filtros de búsqueda de productos
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        filterForm.addEventListener('change', () => filterStaticProducts());
        filterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            filterStaticProducts();
        });
    }
});

let userWishlist = [];

// Obtiene los productos favoritos del usuario
async function fetchWishlistAndRenderHearts() {
    if (window.userIsLoggedIn) {
        try {
            const res = await fetch('php/favoritos.php');
            const data = await res.json();
            if (data.success) {
                userWishlist = data.favoritos.map(f => parseInt(f.producto_id));

                // Marca visualmente los corazones activos
                document.querySelectorAll('.static-heart-btn').forEach(btn => {
                    const card = btn.closest('.product-card');
                    if (card) {
                        const id = parseInt(card.getAttribute('data-id'));
                        if (userWishlist.includes(id)) {
                            btn.classList.add('active');
                        }
                    }
                });
            }
        } catch (e) {
            console.error('Error al recuperar favoritos:', e);
        }
    }
}

// Filtrar en tiempo real los productos estáticos basados en los criterios del formulario
function filterStaticProducts() {
    const form = document.getElementById('filter-form');
    if (!form) return;

    const formData = new FormData(form);
    const buscar = formData.get('buscar').toLowerCase();
    const genero = formData.get('genero');
    const categoria = formData.get('categoria');
    const precio_max = parseInt(formData.get('precio_max'));

    if (precio_max) {
        document.getElementById('price-val').textContent = formatPrice(precio_max);
    }

    const cards = document.querySelectorAll('.product-grid .product-card');

    cards.forEach(card => {
        const c_nombre = (card.getAttribute('data-nombre') || '').toLowerCase();
        const c_genero = card.getAttribute('data-genero') || '';
        const c_categoria = card.getAttribute('data-categoria') || '';
        const c_precio = parseInt(card.getAttribute('data-precio') || '0');

        let match = true;

        // Verifica coincidencia con el texto buscado
        if (buscar && !c_nombre.includes(buscar)) match = false;
        if (genero && c_genero !== genero) match = false;
        if (categoria && c_categoria !== categoria) match = false;
        if (precio_max && c_precio > precio_max) match = false;

        // Mostrar u ocultar la tarjeta del producto según el resultado de la búsqueda
        if (match) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}